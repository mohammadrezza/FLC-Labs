#include <stdio.h> 

int function(int i) 
{ 
  if (i==1) return 1; 
  /* This is a comment */ 
  else return 0;
}
